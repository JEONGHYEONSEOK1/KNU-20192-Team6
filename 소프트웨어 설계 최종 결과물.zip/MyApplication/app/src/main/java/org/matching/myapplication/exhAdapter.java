package org.matching.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class exhAdapter extends BaseAdapter implements View.OnClickListener{

    public interface ListBtnClickListener {
        void onListBtnClick(final apmt x) ;
    }
    private ListBtnClickListener listBtnClickListener ;

    Context exContext = null;
    LayoutInflater exLayoutInflater = null;
    ArrayList<appointment> appointments;
    private DatabaseReference mFirebaseReference;

    public exhAdapter(Context context, ArrayList<appointment> arrayList,ListBtnClickListener clickListener) {
        exContext = context;
        appointments = arrayList;
        exLayoutInflater = LayoutInflater.from(exContext);
        this.listBtnClickListener = clickListener ;
    }

    @Override
    public int getCount() {
        return appointments.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public appointment getItem(int position) {
        return appointments.get(position);
    }



    @Override
    public View getView(final int position, View converView, ViewGroup parent) {
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();

        View view = exLayoutInflater.inflate(R.layout.exhlistview, null); // xml
        final Context context = parent.getContext();

        TextView date = (TextView) view.findViewById(R.id.et1);
        TextView time = (TextView) view.findViewById(R.id.et2);
        TextView content = (TextView) view.findViewById(R.id.et3);
        TextView user = (TextView) view.findViewById(R.id.et4);
        TextView state = (TextView) view.findViewById(R.id.et5);

        date.setText(" " + appointments.get(position).getDate());
        time.setText(appointments.get(position).getTime());
        content.setText(" "+appointments.get(position).getContents());
        user.setText(" 내담자 ID: " + appointments.get(position).getUserID());
        state.setText(" " + appointments.get(position).getState());


        final ImageButton button1 = (ImageButton) view.findViewById(R.id.ib1);
        final ImageButton button2 = (ImageButton) view.findViewById(R.id.ib2);


        button1.setTag(new apmt(appointments.get(position).getAn(),"예약 승인",appointments.get(position).getUserID()));
        button1.setOnClickListener(this);

        button2.setTag(new apmt(appointments.get(position).getAn(),"예약 거부",appointments.get(position).getUserID()));
        button2.setOnClickListener(this);

        return view;
    }
    public void onClick(View v) {
        // ListBtnClickListener(MainActivity)의 onListBtnClick() 함수 호출.
        if (this.listBtnClickListener != null) {
            this.listBtnClickListener.onListBtnClick((apmt)v.getTag()) ;
        }
    }
}
