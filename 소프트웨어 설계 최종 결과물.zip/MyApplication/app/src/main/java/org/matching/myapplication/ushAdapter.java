package org.matching.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class ushAdapter extends BaseAdapter implements View.OnClickListener{

    public interface ListBtnClickListener {
        void onListBtnClick(final String x) ;
    }
    private ListBtnClickListener listBtnClickListener ;

    Context usContext = null;
    LayoutInflater usLayoutInflater = null;
    ArrayList<appointment> uappointments;
    private DatabaseReference mFirebaseReference;

    public ushAdapter(Context context, ArrayList<appointment> arrayList,ListBtnClickListener clickListener) {
        usContext = context;
        uappointments = arrayList;
        usLayoutInflater = LayoutInflater.from(usContext);
        this.listBtnClickListener = clickListener ;
    }

    @Override
    public int getCount() {
        return uappointments.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public appointment getItem(int position) {
        return uappointments.get(position);
    }



    @Override
    public View getView(final int position, View converView, ViewGroup parent) {
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();

        View view = usLayoutInflater.inflate(R.layout.ushlistview, null); // xml
        final Context context = parent.getContext();

        TextView date = (TextView) view.findViewById(R.id.ut1);
        TextView time = (TextView) view.findViewById(R.id.ut2);
        TextView content = (TextView) view.findViewById(R.id.ut3);
        TextView user = (TextView) view.findViewById(R.id.ut4);
        TextView state = (TextView) view.findViewById(R.id.ut5);

        date.setText(" " + uappointments.get(position).getDate());
        time.setText(uappointments.get(position).getTime());
        content.setText(" "+uappointments.get(position).getContents());
        user.setText(" 내담자 ID: " + uappointments.get(position).getUserID());
        state.setText(" " + uappointments.get(position).getState());


        Button button3 = (Button) view.findViewById(R.id.bt);

        button3.setTag(uappointments.get(position).getAn());
        button3.setOnClickListener(this);

        return view;
    }
    public void onClick(View v) {
        // ListBtnClickListener(MainActivity)의 onListBtnClick() 함수 호출.
        if (this.listBtnClickListener != null) {
            this.listBtnClickListener.onListBtnClick((String)v.getTag()) ;
        }
    }
}
