package org.matching.myapplication;

public class apmt {
    private String n;
    private String s;
    private String ui;
    public apmt(String n, String s,String ui) {
        this.n = n;
        this.s = s;
        this.ui = ui;
    }
    public String getN() {
        return n;
    }

    public String getS() {
        return s;
    }

    public String getUi() { return ui; }
}
