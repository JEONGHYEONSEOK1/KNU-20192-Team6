package org.matching.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class user_signup extends AppCompatActivity {
    DatabaseReference mFirebaseReference;
    EditText id2;
    EditText name2;
    EditText password2;
    EditText confirmpassword2;
    EditText phone2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_signup);
        name2 = ((EditText) findViewById(R.id.usersignupname));
        password2 = ((EditText) findViewById(R.id.usersignuppassword));
        confirmpassword2= ((EditText) findViewById(R.id.confirmpassword));
        id2 = ((EditText) findViewById(R.id.usersignupid));
        phone2 = ((EditText) findViewById(R.id.userphonenumber));

    }
    public void on(View v) {
        String id=id2.getText().toString();
        if(id.length()<4||id.length()>12) Toast.makeText(user_signup.this, "아이디 4자 이상 12자 이하로 입력해주세요.", Toast.LENGTH_SHORT).show();
        else {
            state = 0;
            check();
        }
    }
    public void on2(View v) {
        signup();
    }
    private int state=1;
    private void check() {
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child("회원").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String id = ((EditText) findViewById(R.id.usersignupid)).getText().toString();
                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    String dbid = i.getKey();
                    if (dbid.equals(id)==true) state=1;
                }
                if (state == 1) {
                    Toast.makeText(user_signup.this, "이미 가입된 아이디입니다.", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(user_signup.this, "사용 가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
                    state=2;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void signup(){
        final String name =name2.getText().toString();
        final String password = password2.getText().toString();
        final String confirmpassword= confirmpassword2.getText().toString();
        final String phone= phone2.getText().toString();
        final String phonecheck="^(01(?:0|1|[6-9]))-(\\d{3}|\\d{4})-(\\d{4})$";
        final String id=id2.getText().toString();
        if(state!=2){
            Toast.makeText(user_signup.this, "중복확인을 부탁드립니다", Toast.LENGTH_SHORT).show();
        }
        else {
            mFirebaseReference = FirebaseDatabase.getInstance().getReference();
            mFirebaseReference.child("회원").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    String id = ((EditText) findViewById(R.id.usersignupid)).getText().toString();
                    for (DataSnapshot i : dataSnapshot.getChildren()) {
                        String dbid = i.getKey();
                        if (dbid.equals(id) == true) state = 1;
                    }
                    if (state == 1) {
                        Toast.makeText(user_signup.this, "중복확인을 부탁드립니다", Toast.LENGTH_SHORT).show();
                    }
                    else if(TextUtils.isEmpty(name))Toast.makeText(user_signup.this, "이름을 입력해주세요", Toast.LENGTH_SHORT).show();
                    else if(password.length()<6||password.length()>15)Toast.makeText(user_signup.this, "비밀번호는 6자 이상 15자 이하로 입력해주세요", Toast.LENGTH_SHORT).show();
                    else if(confirmpassword.equals(password)==false)Toast.makeText(user_signup.this, "비밀번호를 확인해주세요", Toast.LENGTH_SHORT).show();
                    else if(phone.matches(phonecheck)==false)Toast.makeText(user_signup.this, "휴대폰 번호를 제대로 입력해주세요", Toast.LENGTH_SHORT).show();
                    else {
                        mFirebaseReference.child("회원").child(id);
                        mFirebaseReference.child("회원").child(id).child("이름").setValue(name);
                        mFirebaseReference.child("회원").child(id).child("패스워드").setValue(password);
                        mFirebaseReference.child("회원").child(id).child("휴대폰번호").setValue(phone);
                        mFirebaseReference.child("회원").child(id).child("포인트").setValue(0);
                        Toast.makeText(user_signup.this, "회원가입이 완료되었습니다", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(user_signup.this,MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }
    @Override
    public void onBackPressed() {
        Intent intent=new Intent(user_signup.this,MainActivity.class);
        startActivity(intent);
        finish();
    }

}
