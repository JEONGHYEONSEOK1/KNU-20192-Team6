package org.matching.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class myAdapter extends BaseAdapter { // xml에 정의된 형식들을 arraylist의 데이터를 바탕으로 set하는 과정

    Context mContext = null;
    LayoutInflater mLayoutInflater = null;
    ArrayList<Expert> profiles;


    FirebaseStorage storage = FirebaseStorage.getInstance();

    public myAdapter(Context context, ArrayList<Expert> arrayList) {
        mContext = context;
        profiles = arrayList;
        mLayoutInflater = LayoutInflater.from(mContext);
    }

    @Override
    public int getCount() {
        return profiles.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Expert getItem(int position) {
        return profiles.get(position);
    }



    @Override
    public View getView(int position, View converView, ViewGroup parent) {
        View view = mLayoutInflater.inflate(R.layout.mlistview, null); // xml

        ImageView imageView = (ImageView) view.findViewById(R.id.image);
        TextView name = (TextView) view.findViewById(R.id.E1);
        TextView number = (TextView) view.findViewById(R.id.E2);
        TextView field = (TextView) view.findViewById(R.id.E3);
        TextView career = (TextView) view.findViewById(R.id.E4);
        TextView career1 = (TextView) view.findViewById(R.id.E5);

        StorageReference storageRef = storage.getReferenceFromUrl("gs://damatching.appspot.com/" + profiles.get(position).getEID() + ".jpg");

        GlideApp.with(mContext)
                .load(storageRef)
                .into(imageView);

        name.setText(" 이름: " + profiles.get(position).getName());
        number.setText(" 전화번호: " + profiles.get(position).getNumber());
        field.setText(" 상세분야: " + profiles.get(position).getField());
        career.setText(" 경력: " + profiles.get(position).getCareer());
        career1.setText("          " + profiles.get(position).getCareer1());
        return view;
    }
}
