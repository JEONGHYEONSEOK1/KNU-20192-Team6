package org.matching.myapplication;

public class appointment  {


    private String date;
    private String time;
    private String contents;
    private String expertID;
    private String userID;
    private int cost;
    private int point;
    private String an;
    private String state;

    public appointment(String date, String time,String contents,String expertID,String userID,int cost,int point,String state,String an){
        this.date=date;
        this.time=time;
        this.contents = contents;
        this.expertID = expertID;
        this.userID = userID;
        this.cost = cost;
        this.point = point;
        this.an = an;
        this.state = state;
    }

    public String getDate() { return this.date; }

    public String getTime() { return  this.time; }

    public String getContents() { return this.contents; }

    public String getExpertID()
    {
        return this.expertID;
    }

    public String getUserID()
    {
        return this.userID;
    }

    public int getCost() { return this.cost; }

    public int getPoint() { return this.point; }

    public String getState() { return this.state; }

    public String getAn() { return this.an; }
}
