package org.matching.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static org.matching.myapplication.MainActivity.sharePref;

public class exhistory extends AppCompatActivity implements exhAdapter.ListBtnClickListener{
    private int userpoint;
    private String expertid;
    final ArrayList<appointment> HList = new ArrayList<>();
    private DatabaseReference mFirebaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exhistory);

        expertid=sharePref.getString("id","");
        ListView listView = (ListView) findViewById(R.id.lv);
        final exhAdapter eadapter = new exhAdapter(this ,HList,this);
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child("예약").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    if (i.child("전문가").getValue(String.class).equals(expertid) == true) {
                        HList.add(new appointment(i.child("날짜").getValue(String.class), i.child("시간").getValue(String.class), i.child("상담내용").getValue(String.class), i.child("전문가").getValue(String.class),
                                i.child("회원").getValue(String.class), i.child("가격").getValue(Integer.class), i.child("사용포인트").getValue(Integer.class), i.child("상태").getValue(String.class),i.getKey()));
                        eadapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        listView.setAdapter(eadapter);
    }

    public void onexlogout(View v) {
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
        finish();
    }
    @Override
    public void onListBtnClick(final apmt k) {
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child("예약").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    if (i.getKey().equals(k.getN()) == true) {
                        if (i.child("상태").getValue(String.class).equals("예약 대기") == true) {
                            mFirebaseReference.child("예약").child(k.getN()).child("상태").setValue(k.getS());
                            if(k.getS().equals("예약 거부")) {
                                userpoint = i.child("사용포인트").getValue(Integer.class);
                                mFirebaseReference.child("회원").addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        for (DataSnapshot j : dataSnapshot.getChildren()) {
                                            if (j.getKey().equals(k.getUi()) == true) {
                                                userpoint = userpoint + j.child("포인트").getValue(Integer.class);
                                                        mFirebaseReference.child("회원").child(k.getUi()).child("포인트").setValue(userpoint);
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                    }
                                });
                            }
                            Intent intent = getIntent();
                            finish();
                            startActivity(intent);
                        }
                        else
                        {
                            Toast.makeText(exhistory.this, "'예약 대기'상태에서만 승인/거부가 가능합니다.\n문의는 고객센터(053-123-1234)로 해주시길 바랍니다.", Toast.LENGTH_SHORT).show();
                        }
                    }

                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    public void onBackPressed() {
        // AlertDialog 빌더를 이용해 종료시 발생시킬 창을 띄운다
        AlertDialog.Builder alBuilder = new AlertDialog.Builder(this);
        alBuilder.setMessage("종료하시겠습니까?");

        // "예" 버튼을 누르면 실행되는 리스너
        alBuilder.setPositiveButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish(); // 현재 액티비티를 종료한다. (MainActivity에서 작동하기 때문에 애플리케이션을 종료한다.)
            }
        });
        // "아니오" 버튼을 누르면 실행되는 리스너
        alBuilder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return; // 아무런 작업도 하지 않고 돌아간다
            }
        });
        alBuilder.setTitle("프로그램 종료");
        alBuilder.show(); // AlertDialog.Bulider로 만든 AlertDialog를 보여준다.
    }
}

