package org.matching.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static org.matching.myapplication.MainActivity.sharePref;

public class myreservation extends AppCompatActivity implements ushAdapter.ListBtnClickListener {
    private String userid;
    private int mypoint=0;
    final ArrayList<appointment> UHList = new ArrayList<>();
    private DatabaseReference mFirebaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myreservation);

        userid=sharePref.getString("id","");
        ListView listView = (ListView) findViewById(R.id.ulv);
        final ushAdapter uadapter = new ushAdapter(this ,UHList,this);
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child("예약").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    if (i.child("회원").getValue(String.class).equals(userid) == true) {
                        UHList.add(new appointment(i.child("날짜").getValue(String.class), i.child("시간").getValue(String.class), i.child("상담내용").getValue(String.class), i.child("전문가").getValue(String.class),
                                i.child("회원").getValue(String.class), i.child("가격").getValue(Integer.class), i.child("사용포인트").getValue(Integer.class), i.child("상태").getValue(String.class),i.getKey()));
                        uadapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        listView.setAdapter(uadapter);

        final TextView ptx = (TextView) findViewById(R.id.ptx);
        mFirebaseReference.child("회원").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    if (i.getKey().equals(userid) == true) {
                        ptx.setText(Integer.toString(i.child("포인트").getValue(Integer.class))+"point");
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


    }
    @Override
    public void onListBtnClick(final String k) {
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child("예약").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    if (i.getKey().equals(k) == true) {
                        if (i.child("상태").getValue(String.class).equals("예약 대기") == true) {
                            mFirebaseReference.child("예약").child(k).child("상태").setValue("예약 취소");
                            mypoint = i.child("사용포인트").getValue(Integer.class);
                            mFirebaseReference.child("회원").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    for (DataSnapshot j : dataSnapshot.getChildren()) {
                                        if (j.getKey().equals(userid) == true) {
                                            mypoint = mypoint + j.child("포인트").getValue(Integer.class);
                                            mFirebaseReference.child("회원").child(userid).child("포인트").setValue(mypoint);
                                        }
                                    }
                                    Intent intent = getIntent();
                                    finish();
                                    startActivity(intent);
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                }
                            });
                        }
                        else
                        {
                            Toast.makeText(myreservation.this, "'예약 대기'상태에서만 취소가 가능합니다.", Toast.LENGTH_SHORT).show();
                        }
                    }

                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

}