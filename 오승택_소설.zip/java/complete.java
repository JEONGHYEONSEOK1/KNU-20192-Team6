package org.matching.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class complete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.complete);
    }
    public void onmain(View v) {
        Toast.makeText(complete.this, "메인화면으로 이동합니다.", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(getApplicationContext(),category.class);
        startActivity(intent);
        finish();
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(complete.this, "메인화면으로 이동합니다.", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(getApplicationContext(),category.class);
        startActivity(intent);
        finish();
    }
}