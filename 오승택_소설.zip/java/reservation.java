package org.matching.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static org.matching.myapplication.MainActivity.sharePref;

public class reservation extends AppCompatActivity {
    private DatabaseReference mFirebaseReference;
    static SharedPreferences sharePref1=null;
    static SharedPreferences.Editor editor1=null;
    private int renumber=0;
    private int userpoint=0;
    private String expertid;
    private String exde;
    private String id;
    private int expertprice;
    private int price;
    TextView P;
    EditText Date;
    EditText Time;
    EditText Content;
    EditText Point;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        sharePref1= getSharedPreferences("Reservation",MODE_PRIVATE);
        editor1=sharePref1.edit();
        id=sharePref.getString("id","");
        expertid = intent.getStringExtra("전문가ID");
        exde = intent.getStringExtra("exde");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation);
        Date = ((EditText) findViewById(R.id.redate));
        Time = ((EditText) findViewById(R.id.retime));
        Content = ((EditText) findViewById(R.id.recontent));
        Point = ((EditText) findViewById(R.id.repoint));
        P=((TextView)findViewById(R.id.reprice));
        editor1.putInt("포인트",0);
        editor1.commit();
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child("회원").child(id).child("포인트").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                userpoint = dataSnapshot.getValue(Integer.class);
                editor1.putInt("유저포인트",userpoint);
                editor1.commit();
                int up=sharePref1.getInt("유저포인트",0);
                Log.d("price",String.valueOf(up));
                Point.setHint("보유 포인트 : "+String.valueOf(userpoint));
                Log.d("price",String.valueOf(userpoint));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mFirebaseReference.child("전문가").child(expertid).child("비용").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                price = dataSnapshot.getValue(Integer.class);
                editor1.putInt("전문가비용",price);
                editor1.commit();
                Log.d("price",String.valueOf(price));
                P.setText(String.valueOf(price)+"원");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void onadapt(View v){
        final String point=Point.getText().toString();
        if(TextUtils.isEmpty(point)==false) {
            final int strpoint = Integer.parseInt(Point.getText().toString());
            expertprice = sharePref1.getInt("전문가비용", 0);
            userpoint = sharePref1.getInt("유저포인트", 0);
            if (strpoint > expertprice)
                Toast.makeText(reservation.this, "포인트는 총 비용을 초과할 수 없습니다.", Toast.LENGTH_SHORT).show();
                if (userpoint >= strpoint) {
                    P.setText(String.valueOf(expertprice - strpoint) + "원");
                    editor1.putInt("포인트", strpoint);
                    editor1.commit();
                } else
                    Toast.makeText(reservation.this, "현재 보유하신 포인트는 " + userpoint + " 입니다", Toast.LENGTH_SHORT).show();
            }
        else {
            Toast.makeText(reservation.this, "포인트를 입력하세요", Toast.LENGTH_SHORT).show();
        }
    }
    public void oncomplete(View v) {
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        expertprice = sharePref1.getInt("전문가비용", 0);
        final int endpoint = sharePref1.getInt("포인트",0);
        final int endprice= expertprice-endpoint;
        final String date=Date.getText().toString();
        final String time=Time.getText().toString();
        final String content=Content.getText().toString();
        final String point=Point.getText().toString();
        userpoint=sharePref1.getInt("유저포인트",0);
        String datecheck="^([12]\\d{3}.(0[1-9]|1[0-2]).(0[1-9]|[12][0-9]|3[01]))$";
        String timecheck="^([01][0-9]|2[0-4]):([0-5][0-9])~([01][0-9]|2[0-4]):([0-5][0-9])$";
        if(date.matches(datecheck)==false) Toast.makeText(reservation.this, "날짜를 제대로 입력해주세요", Toast.LENGTH_SHORT).show();
        else if(time.matches(timecheck)==false)Toast.makeText(reservation.this, "시간을 제대로 입력해주세요", Toast.LENGTH_SHORT).show();
        else if(TextUtils.isEmpty(content))Toast.makeText(reservation.this, "상담 내용을 입력해주세요", Toast.LENGTH_SHORT).show();
        else {
            mFirebaseReference.child("예약번호").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    renumber = dataSnapshot.getValue(Integer.class)+1;
                    mFirebaseReference.child("예약").child(Integer.toString(renumber)).child("날짜").setValue(date);
                    mFirebaseReference.child("예약").child(Integer.toString(renumber)).child("시간").setValue(time);
                    mFirebaseReference.child("예약").child(Integer.toString(renumber)).child("상담내용").setValue(content);
                    mFirebaseReference.child("예약").child(Integer.toString(renumber)).child("회원").setValue(id);
                    mFirebaseReference.child("예약").child(Integer.toString(renumber)).child("전문가").setValue(expertid);
                    mFirebaseReference.child("예약").child(Integer.toString(renumber)).child("상태").setValue("예약 대기");
                    mFirebaseReference.child("예약").child(Integer.toString(renumber)).child("가격").setValue(endprice);
                    mFirebaseReference.child("예약").child(Integer.toString(renumber)).child("사용포인트").setValue(endpoint);
                    mFirebaseReference.child("회원").child(id).child("포인트").setValue(userpoint-endpoint);
                    mFirebaseReference.child("예약번호").setValue(renumber);
                    Toast.makeText(reservation.this, "결제가 완료되었습니다", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(reservation.this,complete.class);
                    startActivity(intent);
                    finish();
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
    }
    public void onBackPressed() {
        Intent intent=new Intent(reservation.this,exdetail.class);
        intent.putExtra("exid",expertid);
        intent.putExtra("exd",exde);
        startActivity(intent);
        finish();
    }

}