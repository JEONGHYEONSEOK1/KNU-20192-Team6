package org.matching.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class exdetail extends AppCompatActivity {
    DatabaseReference mFirebaseReference;
    FirebaseStorage storage;
    StorageReference storageRef;
    private String exd;
    private String Exid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exdetail);
        Intent intent = getIntent();
        Exid = intent.getStringExtra("exid");
        exd = intent.getStringExtra("exd");
        final ImageView iv1 = (ImageView) findViewById(R.id.im1);
        final TextView tv1 = (TextView)findViewById(R.id.tx1);
        final TextView tv2 = (TextView)findViewById(R.id.tx2);
        final TextView tv3 = (TextView)findViewById(R.id.tx3);
        final TextView tv4 = (TextView)findViewById(R.id.tx4);
        final TextView tv5 = (TextView)findViewById(R.id.tx5);
        final TextView tv6 = (TextView)findViewById(R.id.tx6);
        final TextView tv7 = (TextView)findViewById(R.id.tx7);
        final TextView tv8 = (TextView)findViewById(R.id.tx8);
        final TextView tv9 = (TextView)findViewById(R.id.tx10);
        final TextView tv10 = (TextView)findViewById(R.id.tx11);
        final TextView tv11 = (TextView)findViewById(R.id.tx12);
        final TextView tv12 = (TextView)findViewById(R.id.tx9);
        final TextView tv13 = (TextView)findViewById(R.id.tx13);

        storage = FirebaseStorage.getInstance();

        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child("전문가").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot i : dataSnapshot.getChildren()) {
                    // 여기서 arraylist에 넣어줘야 함.
                    if(i.getKey().equals(Exid)==true)
                    {
                        tv1.setText(" 이름: "+i.child("이름").getValue(String.class));
                        tv2.setText(" 전화번호: "+i.child("휴대폰번호").getValue(String.class));
                        tv3.setText(" E-mail: "+i.child("이메일").getValue(String.class));
                        tv4.setText(" 전문분야: "+i.child("상세분야").getValue(String.class));
                        tv5.setText(" 경력: "+i.child("경력").getValue(String.class));
                        tv6.setText("          "+i.child("경력1").getValue(String.class));
                        tv7.setText("          "+i.child("경력2").getValue(String.class));
                        tv8.setText("          "+i.child("경력3").getValue(String.class));
                        tv9.setText(Integer.toString( i.child("비용").getValue(Integer.class)) + "원");
                        tv10.setText("          " + i.child("시간1").getValue(String.class));
                        tv11.setText("          " + i.child("시간2").getValue(String.class));
                        tv12.setText("          " + i.child("시간3").getValue(String.class));
                        tv13.setText(i.child("주소").getValue(String.class));
                        storageRef = storage.getReferenceFromUrl("gs://damatching.appspot.com/" + i.getKey() + ".jpg");

                        Glide.with(getApplicationContext())    //Context입력
                                .load(storageRef)    //이미지 리소스
                                .into(iv1);    //표시할 이미지 뷰
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    public void onreservation(View v) {
        Intent intent = new Intent(getApplicationContext(),reservation.class);
        intent.putExtra("전문가ID",Exid);
        intent.putExtra("exde",exd);
        startActivity(intent);
        finish();
    }
    @Override
    public void onBackPressed() {
        Intent intent=new Intent(exdetail.this,exlist.class);
        intent.putExtra("exdetail",exd);
        startActivity(intent);
        finish();
    }
}