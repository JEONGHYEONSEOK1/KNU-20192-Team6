package org.matching.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class exlist extends AppCompatActivity {

    private String detail;
    ArrayList<Expert> EList = new ArrayList<>();
    private DatabaseReference mFirebaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exlist);
        Intent intent = getIntent();
        detail = intent.getStringExtra("exdetail");
        ListView listView=(ListView) findViewById(R.id.listview);
        final myAdapter adapter = new myAdapter(this ,EList);
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child("전문가").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot i : dataSnapshot.getChildren()) {
                    // 여기서 arraylist에 넣어줘야 함.
                    if(i.child("분야").getValue(String.class).equals(detail)== true&&i.child("자격상태").getValue(String.class).equals("1")==true)
                    {
                        EList.add(new Expert(i.child("이름").getValue(String.class) , i.child("휴대폰번호").getValue(String.class) , i.child("상세분야").getValue(String.class) , i.child("경력").getValue(String.class), i.child("경력1").getValue(String.class),i.getKey() ));
                        adapter.notifyDataSetChanged();
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id){
                Intent intent = new Intent(getApplicationContext(),exdetail.class);
                intent.putExtra("exid",adapter.getItem(position).getEID());
                intent.putExtra("exd",detail);
                startActivity(intent);
                finish();
            }
        });

    }
    @Override
    public void onBackPressed() {
        Intent intent=new Intent(exlist.this,category.class);
        startActivity(intent);
        finish();
    }
}