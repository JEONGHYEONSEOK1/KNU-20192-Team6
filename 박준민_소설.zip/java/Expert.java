package org.matching.myapplication;


public class Expert {
    private String name;
    private String number;
    private String field;
    private String career;
    private String career1;
    private String EID;

    public Expert(String name, String number,String field,String career,String career1,String EID){
        this.name=name;
        this.number=number;
        this.field = field;
        this.career = career;
        this.career1 = career1;
        this.EID = EID;
    }

    public String getName() { return this.name; }

    public String getNumber() { return  this.number; }

    public String getCareer() { return this.career; }

    public String getCareer1()
    {
        return this.career1;
    }

    public String getField()
    {
        return this.field;
    }

    public String getEID() { return this.EID; }
}
