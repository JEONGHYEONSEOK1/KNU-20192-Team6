package org.matching.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class SharedPreference {
    static final String PREF_IMAGE_NUMBER = "imagenumber";

    static SharedPreferences getSharedPreferences(Context ctx) {
        return PreferenceManager.getDefaultSharedPreferences(ctx);
    }

    // 계정 정보 저장 (로그인에서만 활용)
    public static void setNumber(Context ctx, int number) {
        SharedPreferences.Editor editor = getSharedPreferences(ctx).edit();
        editor.putInt(PREF_IMAGE_NUMBER, number);
        editor.commit();
    }
    // 저장된 정보 가져오기
    public static int getNumber(Context ctx) {
        return getSharedPreferences(ctx).getInt(PREF_IMAGE_NUMBER, 0);
    }
}
