package org.matching.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class expert_signup extends AppCompatActivity {
    DatabaseReference mFirebaseReference;
    EditText id1;
    EditText password1;
    EditText name1;
    EditText phone1;
    EditText field1;
    EditText email1;
    EditText confirmpassword1;
    TextView imtx;
    private Button btChoose;
    private Uri filePath;
    FirebaseStorage storage;
    StorageReference storageRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expert_signup);
        name1 = ((EditText) findViewById(R.id.expertsignupname));
        password1 = ((EditText) findViewById(R.id.expertsignuppassword));
        confirmpassword1= ((EditText) findViewById(R.id.expertconfirmpassword));
        phone1= ((EditText) findViewById(R.id.expertsignupphone));
        id1 = ((EditText) findViewById(R.id.expertsignupid));
        field1=((EditText)findViewById(R.id.expertsignupfield));
        email1=((EditText)findViewById(R.id.expertsignupemail));
        btChoose = (Button) findViewById(R.id.button5);
        imtx = (TextView) findViewById(R.id.itx);
        storage = FirebaseStorage.getInstance();
        btChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //이미지를 선택, 갤러리 어플로 이동
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "이미지를 선택하세요."), 0);
            }
        });
    }
    private int state = 0;
    public void on4(View v) {
        String id = ((EditText) findViewById(R.id.expertsignupid)).getText().toString();
        if (id.length() < 4 || id.length() > 12)
            Toast.makeText(expert_signup.this, "아이디 4자 이상 12자 이하로 입력해주세요.", Toast.LENGTH_SHORT).show();
        else {
            state = 0;
            check();
        }
    }
    public void on5(View v){
        signup();
    }
    private void check () {
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child("전문가").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String id = ((EditText) findViewById(R.id.expertsignupid)).getText().toString();
                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    String dbid = i.getKey();
                    if (dbid.equals(id) == true) state = 1;
                }
                if (state == 1) {
                    Toast.makeText(expert_signup.this, "이미 가입된 아이디입니다.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(expert_signup.this, "사용 가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
                    state = 2;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void signup(){
        final String name = name1.getText().toString();
        final String password = password1.getText().toString();
        final String confirmpassword= confirmpassword1.getText().toString();
        final String phone= phone1.getText().toString();
        final String id = id1.getText().toString();
        final String field=field1.getText().toString();
        final String email=email1.getText().toString();
        final String phonecheck="^(01(?:0|1|[6-9]))-(\\d{3}|\\d{4})-(\\d{4})$";
        if(state!=2){
            Toast.makeText(expert_signup.this, "중복확인을 부탁드립니다", Toast.LENGTH_SHORT).show();
        }
        else {
            mFirebaseReference = FirebaseDatabase.getInstance().getReference();
            mFirebaseReference.child("전문가").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    String id = ((EditText) findViewById(R.id.expertsignupid)).getText().toString();
                    String emailcheck="^[_a-z0-9-]+(.[_a-z0-9-]+)*@(?:\\w+\\.)+\\w+$";
                    for (DataSnapshot i : dataSnapshot.getChildren()) {
                        String dbid = i.getKey();
                        if (dbid.equals(id) == true) state = 1;
                    }
                    if (state == 1) {
                        Toast.makeText(expert_signup.this, "중복확인을 부탁드립니다", Toast.LENGTH_SHORT).show();
                    }
                    else if(TextUtils.isEmpty(name))Toast.makeText(expert_signup.this, "이름을 입력해주세요", Toast.LENGTH_SHORT).show();
                    else if(password.length()<6||password.length()>15)Toast.makeText(expert_signup.this, "비밀번호는 6자 이상 15자 이하로 입력해주세요", Toast.LENGTH_SHORT).show();
                    else if(confirmpassword.equals(password)==false)Toast.makeText(expert_signup.this, "비밀번호를 확인해주세요", Toast.LENGTH_SHORT).show();
                    else if(phone.matches(phonecheck)==false)Toast.makeText(expert_signup.this, "휴대폰 번호를 제대로 입력해주세요", Toast.LENGTH_SHORT).show();
                    else if(email.matches(emailcheck)==false)Toast.makeText(expert_signup.this, "이메일을 제대로 입력해주세요", Toast.LENGTH_SHORT).show();
                    else if(field.equals("심리")==false&&field.equals("건강")==false&&field.equals("여행")==false&&field.equals("법률")==false)Toast.makeText(expert_signup.this, "분야를 젛확히 입력해주세요", Toast.LENGTH_SHORT).show();
                    else if(imtx.length()<5) Toast.makeText(expert_signup.this, "사진을 첨부해주세요", Toast.LENGTH_SHORT).show();
                    else {
                        int tmp = SharedPreference.getNumber(getApplicationContext());
                        uploadFile(id);
                        SharedPreference.setNumber(getApplicationContext(), tmp);
                        mFirebaseReference.child("전문가").child(id);
                        mFirebaseReference.child("전문가").child(id).child("이름").setValue(name);
                        mFirebaseReference.child("전문가").child(id).child("패스워드").setValue(password);
                        mFirebaseReference.child("전문가").child(id).child("휴대폰번호").setValue(phone);
                        mFirebaseReference.child("전문가").child(id).child("분야").setValue(field);
                        mFirebaseReference.child("전문가").child(id).child("이메일").setValue(email);
                        mFirebaseReference.child("전문가").child(id).child("자격상태").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("상세분야").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("경력").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("경력1").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("경력2").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("경력3").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("시간1").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("시간2").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("시간3").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("주소").setValue("0");
                        mFirebaseReference.child("전문가").child(id).child("비용").setValue(0);
                        Toast.makeText(expert_signup.this, "회원가입이 완료되었습니다", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(expert_signup.this,MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //request코드가 0이고 OK를 선택했고 data에 뭔가가 들어 있다면
        if (requestCode == 0 && resultCode == RESULT_OK) {
            filePath = data.getData();
            Toast.makeText(getApplicationContext(), "uri: " + String.valueOf(filePath), Toast.LENGTH_LONG).show();
            imtx.setText("uri: " + String.valueOf(filePath));
        }
    }

    private void uploadFile(String ID) {
        //업로드할 파일이 있으면 수행
        if (filePath != null) {
            Toast.makeText(getApplicationContext(), "업로드 중...", Toast.LENGTH_LONG).show();
            String filename = ID + ".jpg";
            //storage 주소와 폴더 파일명을 지정해 준다.
            storageRef = storage.getReferenceFromUrl("gs://damatching.appspot.com/").child(filename);
            //업로드
            storageRef.putFile(filePath)
                    //성공시
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Toast.makeText(getApplicationContext(), "업로드 완료!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    //실패시
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(), "업로드 실패!", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }
    @Override
    public void onBackPressed() {
        Intent intent=new Intent(expert_signup.this,MainActivity.class);
        startActivity(intent);
        finish();
    }

}
