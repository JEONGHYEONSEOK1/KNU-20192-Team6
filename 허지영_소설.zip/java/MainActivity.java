package org.matching.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private DatabaseReference mFirebaseReference;
    static SharedPreferences sharePref=null;
    static SharedPreferences.Editor editor=null;
    EditText id;
    EditText password;
    CheckBox checkBox1;
    CheckBox checkBox3;
    private int state = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharePref= getSharedPreferences("Auth",MODE_PRIVATE);
        editor=sharePref.edit();
        id = ((EditText) findViewById(R.id.loginid));
        password = ((EditText) findViewById(R.id.loginpassword));
        checkBox1 = (CheckBox) findViewById(R.id.checkBox);
        checkBox3 = (CheckBox) findViewById(R.id.checkBox2);
        Button button = (Button) findViewById(R.id.uspbutton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, user_signup.class);
                startActivity(intent);
                finish();
            }
        });
        Button button2 = (Button) findViewById(R.id.espbutton);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, expert_signup.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void onlogin(View v) {
        String id1 = id.getText().toString();
        String password1 = password.getText().toString();
        if (checkBox1.isChecked() == false && checkBox3.isChecked() == false)
            Toast.makeText(MainActivity.this, "이용자 구분을 해주세요", Toast.LENGTH_SHORT).show();
        else if (TextUtils.isEmpty(id1))
            Toast.makeText(MainActivity.this, "아이디를 입력해주세요", Toast.LENGTH_SHORT).show();
        else if (TextUtils.isEmpty(password1))
            Toast.makeText(MainActivity.this, "비밀번호를 입력해주세요", Toast.LENGTH_SHORT).show();
        else if (checkBox1.isChecked() == true && checkBox3.isChecked() == true)
            Toast.makeText(MainActivity.this, "체크박스를 하나만 선택해주세요", Toast.LENGTH_SHORT).show();
        else {
            if (checkBox1.isChecked() == true && checkBox3.isChecked() == false) {
                idcheck("회원");
            }//이용자
            else if (checkBox1.isChecked() == false && checkBox3.isChecked() == true) {
                idcheck("전문가");
            }//사용자
        }
    }

    private void idcheck(final String string) {
        state = 0;
        final String id1 = id.getText().toString();
        final String password1 = password.getText().toString();
        mFirebaseReference = FirebaseDatabase.getInstance().getReference();
        mFirebaseReference.child(string).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    String dbid = i.getKey();
                    if (dbid.equals(id1) == true) {
                        for (DataSnapshot j : i.getChildren()) {
                            if (j.getKey().equals("패스워드") == true && j.getValue(String.class).equals(password1) == true) {
                                if (string.equals("회원") == true) {
                                    editor.putString("id",id1);
                                    editor.commit();
                                    state = 1;
                                    Toast.makeText(MainActivity.this, "로그인 되었습니다", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getApplicationContext(), category.class);
                                    intent.putExtra("회원아이디", id1);
                                    startActivity(intent);
                                    finish();
                                } else if (string.equals("전문가") == true) {
                                    if (i.child("자격상태").getValue(String.class).equals("1") == true) {
                                        editor.putString("id",id1);
                                        editor.commit();
                                        state = 1;
                                        Toast.makeText(MainActivity.this, "로그인 되었습니다", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(), exhistory.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                    else {
                                        Toast.makeText(MainActivity.this, "자격 검증이 안되었습니다", Toast.LENGTH_SHORT).show();
                                        state=2;
                                    }
                                }
                            }
                        }
                    }
                }
                if (state == 0)
                    Toast.makeText(MainActivity.this, "아이디 또는 비밀번호가 맞지 않습니다", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}


